webpackJsonp([1],{

/***/ 47:
/***/ (function(module, exports, __webpack_require__) {

	/**
	 * Created by Admin on 2017/4/12.
	 */
	var $ = __webpack_require__( 9 ), a = 0, b = 1, c = 2, d = 3, e = 4, dis, i;

	__webpack_require__( 48 );
	__webpack_require__.e/* nsure */(2, function () {
	    dis = $( '.banner-display-none' );
	    for( i = 0;i<=dis.length;i++ ){

	        $(dis[i]).css('display','block');

	    }
	    __webpack_require__( 50 );
	    $( '.banner-move_J' ).slick ( {

	        dots : false,

	        infinite : true,

	        speed : 300,

	        slidesToShow : 1,

	        adaptiveHeight : true,

	        arrows : false,

	        // autoplay:true,
	        //
	        // autoplaySpeed:3000


	    } );

	});


	$( '.banner-move_J' ).on( 'beforeChange', function ( event, slick, currentSlide, nextSlide ) {


	    $( '.slick-left' ).children().

	    eq( currentSlide ).

	    removeClass( 'icon-squre_red' );

	    $( '.slick-left' ).children().

	    eq( currentSlide ).

	    addClass( 'icon-squre_white' );

	    $( '.slick-left' ).children().

	    eq( nextSlide ).

	    addClass( 'icon-squre_red' );

	    $( '.slick-left' ).children().

	    eq( nextSlide ).

	    removeClass( 'icon-squre_white' );


	} );

	$( '.left1' ).click( function () {

	    $( '.banner-move_J' ).slick( 'slickGoTo', a );

	} );

	$( '.left2' ).click( function () {

	    $( '.banner-move_J' ).slick( 'slickGoTo', b );

	} );

	$( '.left3' ).click( function () {

	    $( '.banner-move_J' ).slick( 'slickGoTo', c );

	} );

	$( '.left4' ).click( function () {

	    $( '.banner-move_J' ).slick( 'slickGoTo', d );

	} );

	$( '.left5' ).click( function () {

	    $( '.banner-move_J' ).slick( 'slickGoTo', e );

	} );







/***/ }),

/***/ 48:
1,

/***/ 52:
1,

/***/ 51:
/***/ (function(module, exports, __webpack_require__) {

	/**
	 * 学生资助管理中心首页main 模块
	 */

	var $ = __webpack_require__( 9 );

	__webpack_require__( 52 );

	$( document ).ready( function () {
	        $( ".yan" ).hide();

	    $( ".c-zizhu-notice-module-detail__tab-ul li" ).click( function () {
	            var curIndex = $( this ).index();
	            $( this).parents().siblings(".c-zizhu-module__head-more").children(".c-zizhu-module__body-a").hide().eq(curIndex).show();
	            //$( this).parents().siblings(".c-zizhu-module__head-more").children(".c-zizhu-module__body-a").eq(curIndex).show();
	            //if( curIndex == 0 ){
	            //    $( ".yan" ).hide();
	            //    $( ".ben" ).show();
	            //}else{
	            //    $( ".ben" ).hide();
	            //    $( ".yan" ).show();
	            //}

	            $( this ).parents().children("li").eq( curIndex )
	                .addClass( "cur" )
	                .siblings()
	                .removeClass( 'cur' );
	            $( this).parents().parents().siblings( ".c-zizhu-notice-module-detail__tab-div" ).hide()
	                .eq( curIndex )
	                .show();
	            // 另一种方法: $("div").eq($(".tab li").index(this)).addClass("on").siblings().removeClass('on');
	    }
	    );

	}
	);



/***/ }),

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	/**
	 * Created by Admin on 2017/4/12.
	 */
	__webpack_require__( 1 );
	__webpack_require__( 5 );

	__webpack_require__( 8 );
	__webpack_require__( 47 );

	__webpack_require__( 51 );

	__webpack_require__( 44 );




/***/ })

});